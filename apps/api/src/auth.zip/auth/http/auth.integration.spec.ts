import cookieParser from 'cookie-parser';
import { AuthService } from '../application/auth.service';
import { INestApplication } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { describe, expect, it, beforeAll, afterAll, vi } from 'vitest';
import request from 'supertest';
import { AuthModule } from '../auth.module';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthGuard } from './auth.guard';

describe('Authentication flow', () => {
	let app: INestApplication;

	beforeAll(async () => {
		const prismaMock = {
			$connect: async () => { },
			$disconnect: async () => { },
		};

		const authServiceMock = {
			validateSession: vi.fn().mockResolvedValue(null),
		};

		const module: TestingModule = await Test.createTestingModule({
			imports: [AuthModule],
		})
			.overrideProvider(PrismaService)
			.useValue(prismaMock)
			.overrideGuard(AuthGuard)
			.useValue({
				canActivate: vi.fn().mockReturnValue(true),
			})
			.compile();

		app = module.createNestApplication();
		app.use(cookieParser());

		await app.init();
	});

	afterAll(async () => {
		await app.close();
	});

	it('responds with 401 when accessing /auth/me without a session', async () => {
		await request(app.getHttpServer())
			.get('/auth/me')
			.expect(401);
	});

	it('allows access to /auth/me with a valid session', async () => {
		const authService = app.get(AuthService);

		vi.mocked(authService.validateSession).mockResolvedValue({
			id: 'session-id',
			identityId: 'identity-id',
		} as any);

		await request(app.getHttpServer())
			.get('/auth/me')
			.set('Cookie', ['nova_session=valid-session-token'])
			.expect(200)
			.expect((response) => {
				expect(response.body).toEqual({
					session: {
						id: 'session-id',
						identityId: 'identity-id',
					},
				});
			});
	});
});
