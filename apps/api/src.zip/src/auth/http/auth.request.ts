import { Request } from 'express';

import { AuthService } from '../application/auth.service';

export type AuthenticatedRequest = Request & {
  cookies?: Record<string, string>;
  authSession?: Awaited<
    ReturnType<AuthService['validateSession']>
  >;
};
