import {
	ExecutionContext,
	UnauthorizedException,
} from '@nestjs/common';
import { describe, expect, it, vi } from 'vitest';

import { AuthGuard } from './auth.guard';
import { AuthService } from '../application/auth.service';

function createContext(request: Record<string, unknown>) {
	return {
		switchToHttp: () => ({
			getRequest: () => request,
		}),
	} as unknown as ExecutionContext;
}

describe('AuthGuard', () => {
	it('rejects requests without a session cookie', async () => {
		const authService = {
			validateSession: vi.fn(),
		} as unknown as AuthService;

		const guard = new AuthGuard(authService);

		await expect(
			guard.canActivate(createContext({ cookies: {} })),
		).rejects.toThrow(UnauthorizedException);

		expect(authService.validateSession).not.toHaveBeenCalled();
	});

	it('rejects invalid sessions', async () => {
		const authService = {
			validateSession: vi.fn().mockResolvedValue(null),
		} as unknown as AuthService;

		const guard = new AuthGuard(authService);

		await expect(
			guard.canActivate(
				createContext({
					cookies: {
						nova_session: 'invalid-token',
					},
				}),
			),
		).rejects.toThrow(UnauthorizedException);

		expect(authService.validateSession).toHaveBeenCalledWith(
			'invalid-token',
		);
	});

	it('allows valid sessions and attaches the session to the request', async () => {
		const session = {
			id: 'session-id',
			identityId: 'identity-id',
		};

		const authService = {
			validateSession: vi.fn().mockResolvedValue(session),
		} as unknown as AuthService;

		const guard = new AuthGuard(authService);

		const request: {
			cookies: {
				nova_session: string;
			};
			authSession?: typeof session;
		} = {
			cookies: {
				nova_session: 'valid-token',
			},
		};

		await expect(
			guard.canActivate(createContext(request)),
		).resolves.toBe(true);

		expect(request.authSession).toEqual(session);
		expect(authService.validateSession).toHaveBeenCalledWith(
			'valid-token',
		);
	});
});
